<?php

/*
	[Discuz!] (C)2001-2009 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$Id: mod.inc.php 16697 2008-11-14 07:36:51Z monkey $
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function task_condition() {
}

function task_preprocess() {
}

function task_csc($task = array()) {
	return true;
}

function task_sufprocess() {
}

?>