var promptmsg = {
	'post_newthread' : '点这里发表新话题',
	'post_reply' : '点这里回复该话题',
	'post_subject' : '在这里输入帖子标题',
	'post_message' : '在这里输入帖子内容',
	'post_submit' : '点这里发表帖子',
	'sendpm' : '点这里给TA发送一条短消息',
	'sendpm_message' : '在这里输入短消息内容',
	'sendpm_submit' : '点这里发送短消息',
	'addbuddy' : '点这里把TA加为好友',
	'search_kw' : '点这里输入关键词',
	'search_submit' : '点这里开始搜索',
	'uploadavatar' : '点这里进入头像设置页面',
	'modifyprofile_birthday' : '点这里选择生日',
	'modifyprofile_qq' : '点这里输入您常用的 QQ 号',
	'modifyprofile_submit' : '点这里确认修改'
};