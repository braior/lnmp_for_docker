<?php

/*
	[Discuz!] (C)2001-2009 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$Id: admincp.php 18639 2009-07-08 01:07:40Z monkey $
*/

header('location: ../userapp.php?script=admincp&my_suffix='.$_GET['my_suffix']);

?>